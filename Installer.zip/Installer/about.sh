#!/bin/bash
#About this script

clear
echo -e "Script Auto Install SSH & OpenVPN v2.0" | lolcat 
echo -e ""
echo -e "For Debian 7 32 bit & 64 bit"
echo -e "For VPS with KVM and VMWare virtualization"
echo -e ""
echo -e "Original script by :"
echo -e "* Fornesia"
echo -e "* Rzengineer"
echo -e "* Fawzya"
echo -e ""
echo -e "Mod by Wangzki"
echo -e ""
