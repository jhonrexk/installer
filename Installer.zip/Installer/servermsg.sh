#!/bin/bash
#Script create banner

clear
echo -e ""
echo -e "READ ME FIRST"
echo -e ""
echo -e "* To Save Changes in Nano Editor *"
echo -e "Press Ctrl+X,"
echo -e "Press Y,"
echo -e "Press Enter,"
echo -e ""
echo -e ""
echo -e "* To Close Nano Editor *"
echo -e "Press Ctrl+Z"
echo -e ""
echo -e ""
echo -e "* To Change Server Message *"
echo -e "Please input the following command:"
echo -e "nano /etc/issue.net"
echo -e ""
echo -e ""
