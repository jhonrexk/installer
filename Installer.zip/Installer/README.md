# VPSauto
Auto SSH VPN Script<br>
Recommended OS: Debian 7 x 64 or 32<br><br>
<b>Service Include</b><br>
Openssh : 22 , 444<br>
Dropbear : 143 , 109<br>
Squid : 8000 , 3128<br>
SSL : 443<br>
Openvpn : 1194 (ip:81/client.ovpn)<br>
Webmin : ip:10000<br>
DDOS Deflate<br>
Fail2Ban<br><br>
<b>Run this command</b><br><br>
<b>SSHVPN SCRIPT</b><br>
wget https://raw.githubusercontent.com/wangzki03/VPSauto/master/deb7script.sh && chmod +x deb7script.sh && ./deb7script.sh<br><br>
<b>OCS PANEL SCRIPT</b><br>
wget https://raw.githubusercontent.com/wangzki03/VPSauto/master/ocsscript.sh && chmod +x ocsscript.sh && ./ocsscript.sh<br>
<b>OCS PANEL mod EZ Connect SCRIPT</b><br>
wget https://raw.githubusercontent.com/wangzki03/VPSauto/master/EZmod.sh && chmod +x EZmod.sh && ./EZmod.sh<br><br>
<b>If you get error in ocs install this to the serverthat have error</b><br>
apt-get install libxml-parser-perl<br><br>
<b>Ubuntu 16.04 x64 or Debian 8.10 x64Softether Script</b><br>
wget https://raw.githubusercontent.com/wangzki03/VPSauto/master/SEsetup.sh && chmod +x SEsetup.sh && ./SEsetup.sh<br><br>

<br>
<b>Debian 9 Autoscript sshvpn</b><br>
wget https://raw.githubusercontent.com/wangzki03/VPSauto/master/tool/Deb9 && chmod +x Deb9 && ./Deb9
